﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Lecteur_ST
{
    public class Srt
    {
        public List<string> srtContent = new List<string>();

        private double hours = 0.0;
        private double minutes = 0.0;
        private double seconds = 0.0;
        private double miliseconds = 0.0;

        public double newTime;

        //Récupération du contenu du fichier de sous titre
        public void RecoverySrt(string srtPath)
        {
            using(StreamReader outputFile = new StreamReader(srtPath))
            {
                string content = "";
                while ((content = outputFile.ReadLine()) != null)
                {
                    srtContent.Add(content);
                }
            }
        }

        //Fonction de conversion du temps indiqué en millisecondes
        public void ConvertTime(string Time)
        {
            //Split 1 : Heures et minutes
            string[] timeBar1 = Time.Split(':');
            hours = double.Parse(timeBar1[0]);
            minutes = double.Parse(timeBar1[1]);

            //Split 2 : Secondes et millisecondes
            string timer = timeBar1[2];
            string[] timeBar2 = timer.Split(',');
            seconds = double.Parse(timeBar2[0]);
            miliseconds = double.Parse(timeBar2[1]);

            //Conversion du tout en millisecondes
            newTime = Math.Round((hours * 3600 * 1000 + minutes * 60 * 1000 + seconds * 1000 + miliseconds), 0);
        }
    }
}
