﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;
using Microsoft.Win32;

namespace Lecteur_ST
{
    /// <summary>
    /// Logique d'interaction pour MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private string fileNameSrt = "";
        private string fileNameMedia = "";

        //private int ID;
        private string beginDate;
        private string endDate;

        private int beginTime;
        private int endTime;
        private int previousBeginTime = 0;


        Srt srt = new Srt();
        public MainWindow()
        {
            InitializeComponent();
        }

        private void OpenFileMedia_Click(object sender, RoutedEventArgs e)
        {
            // Boite de dialogue pour ouvrir le fichier media
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Multiselect = false;
            openFileDialog.Filter = "Video files (*.mp4)|*.mp4|Video files (*.mkv)| *.mkv|All files (*.*)|*.*";
            openFileDialog.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);

            if (openFileDialog.ShowDialog() == true)
            {
                fileNameMedia = openFileDialog.FileName;
                Media.Source = new Uri(openFileDialog.FileName);
            }
        }

        private void OpenFileSrt_Click(object sender, RoutedEventArgs e)
        {
            //Boite de dialogue pour ouvrir le fichier .srt
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Multiselect = false;
            openFileDialog.Filter = "Subtitles files (*.srt)|*.srt";
            openFileDialog.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);

            if (openFileDialog.ShowDialog() == true)
            {
                fileNameSrt = openFileDialog.FileName;
                srt.RecoverySrt(fileNameSrt);
            }
        }

        private async void Play_Click(object sender, RoutedEventArgs e)
        {
            if (fileNameSrt == "" && fileNameMedia == "")
            {
                ST1.Text = "Auncun fichier sélectionné";
            }
            else
            {
                ST1.Text = "Lecture en cours";
                Media.Play();
                await ReadSrt();
            }
        }

        public async Task ReadSrt()
        {
            //Initialisation de l'incrément représentant la ligne dans le fichier
            int i = 0;

            while (i < srt.srtContent.Count)
            {
                //ID = int.Parse(srt.srtContent[i]);
                i++;

                //Récupération de l'heure de début et de fin d'apparition ST dans le fichier
                string[] time = srt.srtContent[i].Split(' ');
                beginDate = time[0];
                endDate = time[2];

                //Conversion heure début d'apparition sous-titre
                srt.ConvertTime(beginDate);
                beginTime = Convert.ToInt32(srt.newTime);

                //Conversion heure fin d'apparition sous-titre
                srt.ConvertTime(beginDate);
                endTime = Convert.ToInt32(srt.newTime);
                i++;

                //Affichage de la partie 1 du sous-titre
                await Task.Delay(beginTime - previousBeginTime);
                ST1.Text = srt.srtContent[i];
                ST2.Text = "";
                

                i++;
                //Affichage de la partie 2 du sous-titre si elle existe
                if (srt.srtContent[i] != "")
                {
                    ST2.Text = srt.srtContent[i];
                    i++;
                }

                previousBeginTime = beginTime;
                i++;
                
            }

        }
    }
}
